import { Chess } from "https://cdn.jsdelivr.net/npm/chess.js@1.4.0/+esm";

const game = new Chess();

const boardEl = document.getElementById("board");
const boardShell = document.getElementById("boardShell");
const statusMain = document.getElementById("statusMain");
const statusSub = document.getElementById("statusSub");
const turnChip = document.getElementById("turnChip");
const moveList = document.getElementById("moveList");
const moveCount = document.getElementById("moveCount");
const whiteCaptured = document.getElementById("whiteCaptured");
const blackCaptured = document.getElementById("blackCaptured");
const newGameBtn = document.getElementById("newGameBtn");
const undoBtn = document.getElementById("undoBtn");
const flipBtn = document.getElementById("flipBtn");
const promotionModal = document.getElementById("promotionModal");
const promotionOptions = document.getElementById("promotionOptions");
const modeButtons = document.querySelectorAll(".mode-btn");
const combatLayer = document.getElementById("combatLayer");
const battleBanner = document.getElementById("battleBanner");
const combatText = document.getElementById("combatText");
const fireflies = document.getElementById("fireflies");

const pieces = {
  w: { k: "♔", q: "♕", r: "♖", b: "♗", n: "♘", p: "♙" },
  b: { k: "♚", q: "♛", r: "♜", b: "♝", n: "♞", p: "♟" }
};

const pieceNames = {
  p: "Pawn",
  n: "Knight",
  b: "Bishop",
  r: "Rook",
  q: "Queen",
  k: "King"
};

let orientation = "white";
let selectedSquare = null;
let selectedMoves = [];
let gameMode = "ai";
let aiThinking = false;
let pendingPromotion = null;
let animatingMove = false;

createFireflies();

function createFireflies() {
  const count = window.innerWidth < 700 ? 24 : 42;
  for (let i = 0; i < count; i += 1) {
    const dot = document.createElement("span");
    dot.className = "firefly";
    dot.style.left = `${4 + Math.random() * 92}%`;
    dot.style.top = `${10 + Math.random() * 75}%`;
    dot.style.setProperty("--x", `${(Math.random() - 0.5) * 90}px`);
    dot.style.setProperty("--y", `${(Math.random() - 0.5) * 70}px`);
    dot.style.setProperty("--time", `${4 + Math.random() * 7}s`);
    dot.style.animationDelay = `${Math.random() * -8}s`;
    fireflies.appendChild(dot);
  }
}

function squareName(row, col) {
  const file = String.fromCharCode(97 + col);
  const rank = 8 - row;
  return `${file}${rank}`;
}

function renderBoard() {
  boardEl.innerHTML = "";
  const board = game.board();
  const rows = orientation === "white" ? [...Array(8).keys()] : [...Array(8).keys()].reverse();
  const cols = orientation === "white" ? [...Array(8).keys()] : [...Array(8).keys()].reverse();
  const lastMove = getLastMoveSquares();

  for (const row of rows) {
    for (const col of cols) {
      const square = squareName(row, col);
      const piece = board[row][col];
      const button = document.createElement("button");
      button.className = `square ${(row + col) % 2 === 0 ? "light" : "dark"}`;
      button.dataset.square = square;
      button.type = "button";

      if (lastMove.includes(square)) button.classList.add("last-move");
      if (selectedSquare === square) button.classList.add("selected");
      if (selectedMoves.some(move => move.to === square)) {
        button.classList.add(piece ? "capture-target" : "legal");
      }

      if (piece) {
        const span = document.createElement("span");
        span.className = `piece animated-piece ${piece.color === "w" ? "white-piece" : "black-piece"}`;
        span.textContent = pieces[piece.color][piece.type];
        button.appendChild(span);

        if (game.inCheck() && piece.color === game.turn() && piece.type === "k") {
          button.classList.add("check");
        }
      }

      const isLeftEdge = orientation === "white" ? col === 0 : col === 7;
      const isBottomEdge = orientation === "white" ? row === 7 : row === 0;

      if (isLeftEdge) {
        const rankLabel = document.createElement("span");
        rankLabel.className = "rank-label";
        rankLabel.textContent = 8 - row;
        button.appendChild(rankLabel);
      }

      if (isBottomEdge) {
        const fileLabel = document.createElement("span");
        fileLabel.className = "file-label";
        fileLabel.textContent = String.fromCharCode(97 + col);
        button.appendChild(fileLabel);
      }

      button.addEventListener("click", () => handleSquareClick(square));
      boardEl.appendChild(button);
    }
  }
}

function getLastMoveSquares() {
  const history = game.history({ verbose: true });
  if (!history.length) return [];
  const last = history[history.length - 1];
  return [last.from, last.to];
}

function handleSquareClick(square) {
  if (aiThinking || animatingMove || game.isGameOver()) return;

  const piece = game.get(square);

  if (!selectedSquare) {
    if (piece && piece.color === game.turn()) selectSquare(square);
    return;
  }

  if (square === selectedSquare) {
    clearSelection();
    renderBoard();
    return;
  }

  if (piece && piece.color === game.turn()) {
    selectSquare(square);
    return;
  }

  const move = selectedMoves.find(item => item.to === square);
  if (!move) {
    statusSub.textContent = "That move is not legal. Try one of the highlighted squares.";
    return;
  }

  if (move.promotion) {
    openPromotionModal(move.from, move.to);
    return;
  }

  performMoveWithAnimation({ from: move.from, to: move.to });
}

function selectSquare(square) {
  selectedSquare = square;
  selectedMoves = game.moves({ square, verbose: true });
  statusSub.textContent = selectedMoves.length
    ? `${pieceNames[game.get(square).type]} selected. Follow the purple path to move.`
    : "This piece has no legal moves.";
  renderBoard();
}

function clearSelection() {
  selectedSquare = null;
  selectedMoves = [];
}

async function performMoveWithAnimation(move) {
  if (animatingMove) return;

  const movingPiece = game.get(move.from);
  if (!movingPiece) return;

  const captured = game.get(move.to);
  const wasAiMove = gameMode === "ai" && movingPiece.color === "b";
  animatingMove = true;
  clearSelection();
  updateButtons();

  try {
    await animateBoardMove(move.from, move.to, movingPiece);
    const madeMove = game.move(move);
    if (!madeMove) return;

    renderAll();
    playMoveTone(Boolean(madeMove.captured));

    if (captured) {
      showCaptureEffect(madeMove, movingPiece, captured);
    }

    if (wasAiMove) {
      statusSub.textContent = captured
        ? "NILA completed a battle capture. Your turn."
        : "NILA moved through the shadow forest. Your turn.";
    }

    if (gameMode === "ai" && game.turn() === "b" && !game.isGameOver()) {
      aiThinking = true;
      renderStatus();
      setTimeout(() => {
        makeAiMove();
      }, 650);
    }
  } catch (error) {
    console.error("Move animation error:", error);
  } finally {
    animatingMove = false;
    updateButtons();
  }
}

function getSquareCenter(square) {
  const element = boardEl.querySelector(`[data-square="${square}"]`);
  if (!element) return null;
  const rect = element.getBoundingClientRect();
  return { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
}

function createMovingPiece(piece) {
  const actor = document.createElement("div");
  actor.className = `moving-piece ${piece.color === "w" ? "white-piece" : "black-piece"}`;
  actor.textContent = pieces[piece.color][piece.type];
  document.body.appendChild(actor);
  return actor;
}

function createTrailDot(x, y) {
  const dot = document.createElement("div");
  dot.className = "trail-dot";
  dot.style.left = `${x}px`;
  dot.style.top = `${y}px`;
  document.body.appendChild(dot);
  setTimeout(() => dot.remove(), 520);
}

function animateBoardMove(from, to, piece) {
  return new Promise(resolve => {
    const start = getSquareCenter(from);
    const end = getSquareCenter(to);
    if (!start || !end) {
      resolve();
      return;
    }

    const actor = createMovingPiece(piece);
    const distance = Math.hypot(end.x - start.x, end.y - start.y);
    const duration = Math.min(680, Math.max(240, 170 + distance * 1.05));
    const steps = piece.type === "n" ? 4 : Math.max(3, Math.round(distance / 60));

    actor.style.left = `${start.x}px`;
    actor.style.top = `${start.y}px`;
    actor.style.transform = "translate(-50%, -50%) scale(1.08)";

    const points = [];
    for (let i = 0; i <= steps; i += 1) {
      const t = i / steps;
      let x = start.x + (end.x - start.x) * t;
      let y = start.y + (end.y - start.y) * t;

      if (piece.type === "n") {
        y -= Math.sin(Math.PI * t) * Math.min(56, Math.max(24, distance * 0.22));
      }
      points.push({ x, y });
    }

    let trailIndex = 0;
    const trailTimer = setInterval(() => {
      const point = points[Math.min(trailIndex, points.length - 1)];
      createTrailDot(point.x, point.y);
      trailIndex += 1;
      if (trailIndex >= points.length) clearInterval(trailTimer);
    }, Math.max(35, duration / (steps + 1)));

    const animation = actor.animate(
      points.map((point, index) => ({
        left: `${point.x}px`,
        top: `${point.y}px`,
        transform: `translate(-50%, -50%) scale(${index === points.length - 1 ? 1 : 1.08}) rotate(${piece.type === "n" ? (index % 2 ? -7 : 7) : 0}deg)`
      })),
      { duration, easing: "cubic-bezier(.16,.72,.22,1)", fill: "forwards" }
    );

    animation.finished
      .catch(() => undefined)
      .finally(() => {
        clearInterval(trailTimer);
        actor.remove();
        resolve();
      });
  });
}

async function makeAiMove() {
  if (game.isGameOver()) {
    aiThinking = false;
    renderAll();
    return;
  }

  const moves = game.moves({ verbose: true });
  if (!moves.length) {
    aiThinking = false;
    renderAll();
    return;
  }

  const bestMove = chooseAiMove(moves, 2);
  await performMoveWithAnimation({
    from: bestMove.from,
    to: bestMove.to,
    ...(bestMove.promotion ? { promotion: "q" } : {})
  });
  aiThinking = false;
  renderAll();
}

function chooseAiMove(moves, depth) {
  let bestScore = -Infinity;
  let candidates = [];

  for (const move of moves) {
    const clone = new Chess(game.fen());
    clone.move({
      from: move.from,
      to: move.to,
      ...(move.promotion ? { promotion: "q" } : {})
    });

    let score = minimax(clone, depth - 1, false);
    if (move.captured) score += 35;
    if (move.san?.includes("+")) score += 20;

    if (score > bestScore) {
      bestScore = score;
      candidates = [move];
    } else if (score === bestScore) {
      candidates.push(move);
    }
  }

  return candidates[Math.floor(Math.random() * candidates.length)] || moves[0];
}

function minimax(position, depth, maximizing) {
  if (depth === 0 || position.isGameOver()) return evaluatePosition(position);

  const moves = position.moves({ verbose: true });
  if (maximizing) {
    let value = -Infinity;
    for (const move of moves) {
      const clone = new Chess(position.fen());
      clone.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: "q" } : {}) });
      value = Math.max(value, minimax(clone, depth - 1, false));
    }
    return value;
  }

  let value = Infinity;
  for (const move of moves) {
    const clone = new Chess(position.fen());
    clone.move({ from: move.from, to: move.to, ...(move.promotion ? { promotion: "q" } : {}) });
    value = Math.min(value, minimax(clone, depth - 1, true));
  }
  return value;
}

function evaluatePosition(position) {
  if (position.isCheckmate()) return position.turn() === "b" ? 100000 : -100000;
  if (position.isDraw()) return 0;

  const values = { p: 100, n: 320, b: 330, r: 500, q: 900, k: 20000 };
  let score = 0;

  for (const row of position.board()) {
    for (const piece of row) {
      if (!piece) continue;
      score += piece.color === "b" ? values[piece.type] : -values[piece.type];
    }
  }

  return score;
}

function openPromotionModal(from, to) {
  pendingPromotion = { from, to };
  promotionOptions.innerHTML = "";

  const color = game.turn();
  const options = ["q", "r", "b", "n"];

  for (const type of options) {
    const button = document.createElement("button");
    button.className = "promotion-choice";
    button.type = "button";
    button.innerHTML = `<span class="promotion-piece">${pieces[color][type]}</span>${pieceNames[type]}`;
    button.addEventListener("click", () => {
      const move = { ...pendingPromotion, promotion: type };
      closePromotionModal();
      performMoveWithAnimation(move);
    });
    promotionOptions.appendChild(button);
  }

  promotionModal.classList.remove("hidden");
}

function closePromotionModal() {
  pendingPromotion = null;
  promotionModal.classList.add("hidden");
}

function showCaptureEffect(move, movingPiece, capturedPiece) {
  const target = getSquareCenter(move.to);
  if (!target) return;

  const boardRect = boardShell.getBoundingClientRect();
  const x = target.x - boardRect.left;
  const y = target.y - boardRect.top;
  const style = (node) => {
    node.style.left = `${x}px`;
    node.style.top = `${y}px`;
  };

  const useSword = ["r", "n", "p", "k"].includes(movingPiece.type);
  const effectType = useSword ? "sword" : "magic";

  showBattleBanner(effectType === "sword" ? "SWORD MASTERY" : "ARCANE BURST");
  combatText.textContent = effectType === "sword" ? "CRITICAL STRIKE!" : "ARCANE IMPACT!";
  combatText.classList.remove("show", "hidden");
  void combatText.offsetWidth;
  combatText.classList.add("show");

  const ring = document.createElement("div");
  ring.className = "combat-ring";
  style(ring);
  combatLayer.appendChild(ring);

  if (effectType === "sword") {
    const slash = document.createElement("div");
    slash.className = "slash";
    style(slash);
    combatLayer.appendChild(slash);
  } else {
    const orb = document.createElement("div");
    orb.className = "magic-orb";
    style(orb);
    combatLayer.appendChild(orb);
  }

  for (let i = 0; i < 14; i += 1) {
    const spark = document.createElement("div");
    spark.className = "spark";
    style(spark);
    const angle = (Math.PI * 2 * i) / 14;
    const distance = 45 + Math.random() * 70;
    spark.style.setProperty("--sx", `${Math.cos(angle) * distance}px`);
    spark.style.setProperty("--sy", `${Math.sin(angle) * distance}px`);
    spark.style.animationDelay = `${Math.random() * 0.08}s`;
    combatLayer.appendChild(spark);
  }

  setTimeout(() => {
    ring.remove();
    combatLayer.querySelectorAll(".slash, .magic-orb, .spark").forEach(node => node.remove());
  }, 800);

  void capturedPiece;
}

function showBattleBanner(text) {
  battleBanner.textContent = text;
  battleBanner.classList.remove("show", "hidden");
  void battleBanner.offsetWidth;
  battleBanner.classList.add("show");
  setTimeout(() => battleBanner.classList.add("hidden"), 620);
}

function renderAll() {
  renderBoard();
  renderStatus();
  renderMoves();
  renderCaptured();
  updateButtons();
}

function renderStatus() {
  if (game.isCheckmate()) {
    const winner = game.turn() === "w" ? "Black wins" : "White wins";
    statusMain.textContent = winner;
    statusSub.textContent = "Checkmate. The forest falls silent. Start a new game to fight again.";
    turnChip.textContent = "GAME OVER";
    return;
  }

  if (game.isDraw()) {
    statusMain.textContent = "Draw game";
    statusSub.textContent = "The battle ended without a winner.";
    turnChip.textContent = "DRAW";
    return;
  }

  if (game.inCheck()) {
    statusMain.textContent = game.turn() === "w" ? "WHITE KING IN DANGER" : "BLACK KING IN DANGER";
    statusSub.textContent = "Your king must escape the attack on the next move.";
  } else if (gameMode === "ai" && game.turn() === "b") {
    statusMain.textContent = aiThinking ? "NILA is thinking..." : "NILA's turn";
    statusSub.textContent = aiThinking ? "The shadow mage is choosing its next move." : "The bot controls the black pieces.";
  } else {
    statusMain.textContent = game.turn() === "w" ? "Your move" : "Player 2's move";
    statusSub.textContent = "Select a piece and follow its glowing movement trail.";
  }

  turnChip.textContent = `${game.turn() === "w" ? "WHITE" : "BLACK"} TO MOVE`;
}

function renderMoves() {
  const history = game.history({ verbose: true });
  moveCount.textContent = `${history.length} ${history.length === 1 ? "MOVE" : "MOVES"}`;

  if (!history.length) {
    moveList.innerHTML = '<div class="empty-moves">No moves yet.</div>';
    return;
  }

  moveList.innerHTML = "";
  for (let i = 0; i < history.length; i += 2) {
    const row = document.createElement("div");
    row.className = "move-row";
    const white = history[i];
    const black = history[i + 1];
    row.innerHTML = `
      <span class="move-number">${Math.floor(i / 2) + 1}.</span>
      <span class="move-name">${white.san}</span>
      <span class="move-name">${black ? black.san : ""}</span>
    `;
    moveList.appendChild(row);
  }

  moveList.scrollTop = moveList.scrollHeight;
}

function renderCaptured() {
  const history = game.history({ verbose: true });
  const capturedByWhite = history.filter(move => move.color === "w" && move.captured).map(move => pieces.b[move.captured]);
  const capturedByBlack = history.filter(move => move.color === "b" && move.captured).map(move => pieces.w[move.captured]);
  whiteCaptured.textContent = capturedByWhite.join(" ");
  blackCaptured.textContent = capturedByBlack.join(" ");
}

function updateButtons() {
  undoBtn.disabled = game.history().length === 0 || aiThinking || animatingMove;
  undoBtn.style.opacity = undoBtn.disabled ? "0.45" : "1";
  undoBtn.style.cursor = undoBtn.disabled ? "not-allowed" : "pointer";
}

function newGame() {
  game.reset();
  closePromotionModal();
  clearSelection();
  aiThinking = false;
  animatingMove = false;
  renderAll();
}

function undoMove() {
  if (aiThinking || animatingMove || !game.history().length) return;
  game.undo();
  if (gameMode === "ai" && game.turn() === "b" && game.history().length) game.undo();
  clearSelection();
  renderAll();
}

function setMode(mode) {
  gameMode = mode;
  modeButtons.forEach(button => button.classList.toggle("active", button.dataset.mode === mode));
  document.getElementById("topName").textContent = mode === "ai" ? "NILA BOT" : "PLAYER 2";
  document.getElementById("topStatus").textContent = mode === "ai" ? "Black • Shadow Mage" : "Black • Dark Knight";
  newGame();
}

function playMoveTone(capture) {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const oscillator = ctx.createOscillator();
    const gain = ctx.createGain();
    oscillator.frequency.value = capture ? 180 : 260;
    oscillator.type = capture ? "sawtooth" : "sine";
    gain.gain.setValueAtTime(0.0001, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(capture ? 0.065 : 0.045, ctx.currentTime + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + (capture ? 0.2 : 0.11));
    oscillator.connect(gain);
    gain.connect(ctx.destination);
    oscillator.start();
    oscillator.stop(ctx.currentTime + (capture ? 0.21 : 0.12));
  } catch {
    // Audio is optional; the game works without it.
  }
}

newGameBtn.addEventListener("click", newGame);
undoBtn.addEventListener("click", undoMove);
flipBtn.addEventListener("click", () => {
  orientation = orientation === "white" ? "black" : "white";
  renderBoard();
});
modeButtons.forEach(button => button.addEventListener("click", () => setMode(button.dataset.mode)));

renderAll();
